<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location:login.php");
}

include('koneksi.php');

$host       = "localhost";
$user       = "root";
$pass       = "";
$db         = "monitoring";

$koneksi    = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) { // cek koneksi
    die("Tidak bisa terkoneksi ke database");
}
$cabai        = "";
$nilai_suhu   = "";
$nilai_gas    = "";
$sukses       = "";
$error        = "";

// Create cabai table if not exists
$sql_create_cabai_table = "CREATE TABLE IF NOT EXISTS cabai (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(255) NOT NULL,
    jenis_cabai VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";

$q_create_cabai_table = mysqli_query($koneksi, $sql_create_cabai_table);

if (!$q_create_cabai_table) {
    die("Query error: " . mysqli_error($koneksi));
}

if (isset($_POST['simpan_cabai'])) {
    $nama       = $_POST['nama'];
    $jenis_cabai = $_POST['jenis_cabai'];

    if ($nama && $jenis_cabai) {
        $sql_insert_cabai = "INSERT INTO cabai (nama, jenis_cabai) VALUES ('$nama', '$jenis_cabai')";
        $q_insert_cabai   = mysqli_query($koneksi, $sql_insert_cabai);

        if ($q_insert_cabai) {
            $sukses = "Berhasil memasukkan data baru";
        } else {
            $error = "Gagal memasukkan data: " . mysqli_error($koneksi);
        }
    } else {
        $error = "Silakan masukkan semua data";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- ... (Your existing head section) -->
</head>

<body>
    <div class="mx-auto">
        <!-- ... (Your existing HTML content) -->

        <!-- Form for adding cabai data -->
        <div class="card">
            <div class="card-header">
                Create Cabai Data
            </div>
            <div class="card-body">
                <?php
                if ($error) {
                ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo $error ?>
                    </div>
                <?php
                    header("refresh:5;url=index.php"); // 5 seconds
                }
                ?>
                <?php
                if ($sukses) {
                ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo $sukses ?>
                    </div>
                <?php
                    header("refresh:5;url=index.php");
                }
                ?>
                <form action="" method="POST">
                    <div class="mb-3 row">
                        <label for="nama" class="col-sm-2 col-form-label">Nama</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $nama ?>">
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="jenis_cabai" class="col-sm-2 col-form-label">Jenis Cabai</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jenis_cabai" name="jenis_cabai" value="<?php echo $jenis_cabai ?>">
                        </div>
                    </div>

                    <div class="col-12">
                        <input type="submit" name="simpan_cabai" value="Simpan Data Cabai" class="btn btn-primary" />
                    </div>
                </form>
            </div>
        </div>

        <!-- ... (Your existing HTML content) -->
    </div>
</body>

</html>
