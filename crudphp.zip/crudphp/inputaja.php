<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "monitoring";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Tidak bisa terkoneksi ke database");
}

// Inisialisasi variabel untuk masing-masing form
$namaCabai = "";
$tanggalPlanting = "";
$kematangan = "";
$errorCabai = "";
$suksesCabai = "";

$jenisCabai = "";
$nilaiSuhu = "";
$waktuSuhu = "";
$errorSuhu = "";
$suksesSuhu = "";

$jenisCabaiGas = "";
$konsentrasiGas = "";
$waktuGas = "";
$errorGas = "";
$suksesGas = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Form Cabai
    if (isset($_POST['saveCabai'])) {
        $namaCabai = $_POST['namaCabai'];
        $tanggalPlanting = $_POST['tanggalPlanting'];
        $kematangan = $_POST['kematangan'];

        if ($namaCabai && $tanggalPlanting && $kematangan) {
            $sqlCabai = "INSERT INTO cabai (nama_cabai, tanggal_planting, kematangan) VALUES ('$namaCabai', '$tanggalPlanting', '$kematangan')";
            $resultCabai = mysqli_query($koneksi, $sqlCabai);

            if ($resultCabai) {
                $suksesCabai = "Data Cabai berhasil disimpan";
                $namaCabai = "";
                $tanggalPlanting = "";
                $kematangan = "";
                // Mengarahkan pengguna kembali ke indeks
                header('Location: index.php');
                exit();
            } else {
                $errorCabai = "Gagal menyimpan data Cabai";
            }
        } else {
            $errorCabai = "Silakan masukkan semua data Cabai";
        }
    }

    // Form Suhu
    if (isset($_POST['saveSuhu'])) {
        $jenisCabai = $_POST['jenisCabai'];
        $nilaiSuhu = $_POST['nilaiSuhu'];
        $waktuSuhu = $_POST['waktuSuhu'];

        if ($jenisCabai && $nilaiSuhu && $waktuSuhu) {
            $sqlSuhu = "INSERT INTO suhu (jenis_cabai, nilai_suhu, waktu) VALUES ('$jenisCabai', '$nilaiSuhu', '$waktuSuhu')";
            $resultSuhu = mysqli_query($koneksi, $sqlSuhu);

            if ($resultSuhu) {
                $suksesSuhu = "Data Suhu berhasil disimpan";
                $jenisCabai = "";
                $nilaiSuhu = "";
                $waktuSuhu = "";
                // Mengarahkan pengguna kembali ke indeks
                header('Location: index.php');
                exit();
            } else {
                $errorSuhu = "Gagal menyimpan data Suhu";
            }
        } else {
            $errorSuhu = "Silakan masukkan semua data Suhu";
        }
    }

    // Form Gas (CO2)
    if (isset($_POST['saveGas'])) {
        $jenisCabaiGas = $_POST['jenisCabaiGas'];
        $konsentrasiGas = $_POST['konsentrasiGas'];
        $waktuGas = $_POST['waktuGas'];

        if ($jenisCabaiGas && $konsentrasiGas && $waktuGas) {
            $sqlGas = "INSERT INTO gas (jenis_cabai, konsentrasi_gas, waktu) VALUES ('$jenisCabaiGas', '$konsentrasiGas', '$waktuGas')";
            $resultGas = mysqli_query($koneksi, $sqlGas);

            if ($resultGas) {
                $suksesGas = "Data Gas berhasil disimpan";
                $jenisCabaiGas = "";
                $konsentrasiGas = "";
                $waktuGas = "";
                // Mengarahkan pengguna kembali ke indeks
                header('Location: index.php');
                exit();
            } else {
                $errorGas = "Gagal menyimpan data Gas";
            }
        } else {
            $errorGas = "Silakan masukkan semua data Gas";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Data Cabai, Suhu, dan Gas</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap">
    <style>
        /* Style for tables */
        table {
            border-collapse: collapse;
            width: 90%;
            margin-bottom: 20px;
            
        }

        table, th, td {
            padding: 8px;
            border: 1px solid #ccc;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        /* Style for form sections */
        h2 {
            font-size: 30px;
            color: #333;
            text-align: center;
            margin-top: 100px;
            margin-bottom: 50px;
        }

        table {
            margin-top: 100px;
        }

        h3 {
            background-color: #b7d6f6;
            color: #fff;
            padding: 10px;
        }

        /* Style for success and error messages */
        .success, .error {
            font-weight: bold;
            padding: 8px;
            margin: 10px 0;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }

        /* Style for buttons */
        button {
            background-color: #b7d6f6;
            color: #333333;
            border: none;
            padding: 8px 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Style for labels and input fields */
        label {
            display: block;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="date"],
        input[type="datetime-local"] {
            width: 97%;
            padding: 5px;
            background: #e8f0fe;
            border: 0px;
        }

        /* Style for links */
        a {
            text-decoration: none;
            color: #333333;
            border: none;
            padding: 8px 16px;
            cursor: pointer;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Style for body and form input sections */
        body {
            background-color: #fbd0d9;
            font-family: Poppins, sans-serif;
        }

        /* Style for cards */
        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 16px;
            margin: 16px;
        }
    </style>
</head>
<body>
    <h2>Input Data Cabai, Suhu, dan Gas</h2>

    <!-- Form Input Data Cabai -->
    <div class="card">
        <h3>Form Input Data Cabai</h3>
        <?php if ($errorCabai) : ?>
            <div class="error"><?php echo $errorCabai; ?></div>
        <?php endif; ?>
        <?php if ($suksesCabai) : ?>
            <div class="success"><?php echo $suksesCabai; ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="namaCabai">Nama Cabai:</label>
            <input type="text" id="namaCabai" name="namaCabai" value="<?php echo $namaCabai; ?>" required><br><br>

            <label for="tanggalPlanting">Tanggal Planting:</label>
            <input type="date" id="tanggalPlanting" name="tanggalPlanting" value="<?php echo $tanggalPlanting; ?>" required><br><br>

            <label for="kematangan">Kematangan:</label>
            <input type="text" id="kematangan" name="kematangan" value="<?php echo $kematangan; ?>" required><br><br>

            <button type="submit" name="saveCabai">Save Data Cabai</button>
        </form>
    </div>

    <!-- Form Input Data Suhu -->
    <div class="card">
        <h3>Form Input Data Suhu</h3>
        <?php if ($errorSuhu) : ?>
            <div class="error"><?php echo $errorSuhu; ?></div>
        <?php endif; ?>
        <?php if ($suksesSuhu) : ?>
            <div class="success"><?php echo $suksesSuhu; ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="jenisCabai">Jenis Cabai:</label>
            <input type="text" id="jenisCabai" name="jenisCabai" value="<?php echo $jenisCabai; ?>" required><br><br>

            <label for="nilaiSuhu">Nilai Suhu:</label>
            <input type="text" id="nilaiSuhu" name="nilaiSuhu" value="<?php echo $nilaiSuhu; ?>" required><br><br>

            <label for="waktuSuhu">Waktu:</label>
            <input type="datetime-local" id="waktuSuhu" name="waktuSuhu" value="<?php echo $waktuSuhu; ?>" required><br><br>

            <button type="submit" name="saveSuhu">Save Data Suhu</button>
        </form>
    </div>

    <!-- Form Input Data Gas (CO2) -->
    <div class="card">
        <h3>Form Input Data Gas (CO2)</h3>
        <?php if ($errorGas) : ?>
            <div class="error"><?php echo $errorGas; ?></div>
        <?php endif; ?>
        <?php if ($suksesGas) : ?>
            <div class="success"><?php echo $suksesGas; ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="jenisCabaiGas">Nama Cabai:</label>
            <input type="text" id="jenisCabaiGas" name="jenisCabaiGas" value="<?php echo $jenisCabaiGas; ?>" required><br><br>

            <label for="konsentrasiGas">Konsentrasi Gas (CO2):</label>
            <input type="text" id="konsentrasiGas" name="konsentrasiGas" value="<?php echo $konsentrasiGas; ?>" required><br><br>

            <label for="waktuGas">Waktu:</label>
            <input type="datetime-local" id="waktuGas" name="waktuGas" value="<?php echo $waktuGas; ?>" required><br><br>

            <button type="submit" name="saveGas">Save Data Gas (CO2)</button>
        </form>
    </div>
    
    <!-- Button Kembali ke Indeks -->
    <button onclick="window.location.href='index.php'" style="background-color: #b7d6f6; text-transform: capitalize; color: #333333; border: none; padding: 8px 20px; margin-top: 20px; margin-bottom: 10px; cursor: pointer;">Kembali ke Indeks</button>

</body>
</html>
